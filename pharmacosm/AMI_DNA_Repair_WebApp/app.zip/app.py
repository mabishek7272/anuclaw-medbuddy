import os
import pandas as pd
import tensorflow as tf
from flask import Flask, request, jsonify, render_template
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

# Ensure the uploads folder exists
UPLOAD_FOLDER = "uploads"
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Load AI Model
model = tf.keras.models.load_model("model/Quantum_AMI_DNA_Repair_Model.h5", compile=False)

# Function to classify repair mechanisms
def classify_repair(prediction):
    if prediction > 0.85:
        return "Homologous Recombination (HR)"
    elif prediction > 0.65:
        return "Base Excision Repair (BER)"
    elif prediction > 0.45:
        return "Nucleotide Excision Repair (NER)"
    else:
        return "Non-Homologous End Joining (NHEJ)"

# Function to process raw DNA files
def convert_raw_dna(file_path):
    try:
        # Check file format
        if file_path.endswith(".vcf"):
            df = pd.read_csv(file_path, comment="#", delimiter="\t", header=None)
            df.columns = ["CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO"]
        elif file_path.endswith(".txt"):
            df = pd.read_csv(file_path, delimiter="\t")
        elif file_path.endswith(".csv"):
            df = pd.read_csv(file_path)
        else:
            return None, "Unsupported file format!"

        # Extract mutation features and convert to AI-friendly format
        df["radius_mean"] = df["POS"] / 1000000  # Normalize position
        df["texture_mean"] = df["ALT"].apply(lambda x: len(str(x)))  # Mutation length
        df["perimeter_mean"] = (df["QUAL"] / 100).round(4)  # Round to 4 decimal places

        # Select only AI-readable features
        ai_data = df[["radius_mean", "texture_mean", "perimeter_mean"]]

        # Convert to CSV format
        csv_data = ai_data.to_csv(index=False)

        return csv_data, None
    except Exception as e:
        return None, str(e)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/convert_dna", methods=["POST"])
def convert_dna():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded!"})

        file = request.files["file"]
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)

        converted_data, error = convert_raw_dna(file_path)
        if error:
            return jsonify({"error": error})

        return jsonify({"ai_data": converted_data})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/predict_csv", methods=["POST"])
def predict_csv():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded!"})

        file = request.files["file"]
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)

        # Load CSV File
        df = pd.read_csv(file_path)

        # Required columns
        required_features = ["radius_mean", "texture_mean", "perimeter_mean"]
        for feature in required_features:
            if feature not in df.columns:
                return jsonify({"error": f"Missing required column: {feature}"})

        print("✅ CSV File Received by Flask:")
        print(df.head())  # Debugging: Show first few rows

        # Extract features
        X_test = df[required_features].values

        # Normalize input
        scaler = StandardScaler()
        X_test_scaled = scaler.fit_transform(X_test)

        # Make Predictions
        predictions = model.predict(X_test_scaled)

        # Convert predictions to JSON
        results = []
        for i in range(len(df)):
            repair_type = classify_repair(predictions[i][0])
            results.append({
                "radius_mean": df.iloc[i]["radius_mean"],
                "texture_mean": df.iloc[i]["texture_mean"],
                "perimeter_mean": df.iloc[i]["perimeter_mean"],
                "ami_repair_prediction": float(predictions[i][0]),
                "repair_mechanism": repair_type
            })

        print("✅ Sending JSON response to frontend:", results)  # Debugging

        return jsonify({"predictions": results})
    
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)